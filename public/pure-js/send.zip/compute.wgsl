@group(0) @binding(0) var<uniform> res: vec2f;
@group(0) @binding(1) var<storage> statein: array<f32>;
@group(0) @binding(2) var<storage, read_write> stateout: array<f32>;
@group(0) @binding(3) var<uniform> mouse: vec3f;
@group(0) @binding(4) var<uniform> props: vec4f;

fn index( x:i32, y:i32, b: bool ) -> u32 {
  let _res = vec2i(res);
  return u32( (((y % _res.y) + _res.y) % _res.y) * _res.x + ((x % _res.x) + _res.x) % _res.x ) * 2 + u32(b);
}

fn laplacian(x: i32, y: i32, b: bool) -> f32 {
  return statein[ index(x + 1, y + 1, b) ] * 0.05 +
         statein[ index(x + 1, y, b)     ] * 0.2 +
         statein[ index(x + 1, y - 1, b) ] * 0.05 +
         statein[ index(x, y - 1, b)     ] * 0.2 +
         statein[ index(x - 1, y - 1, b) ] * 0.05 +
         statein[ index(x - 1, y, b)     ] * 0.2 +
         statein[ index(x - 1, y + 1, b) ] * 0.05 +
         statein[ index(x, y + 1, b)     ] * 0.2 +
         statein[ index(x, y, b)         ] * -1;
}

@compute
@workgroup_size(8,8)
fn cs( @builtin(global_invocation_id) _cell:vec3u ) {
  let cell = vec3i(_cell);
  let _res = vec2i(res);
  if (cell.x >= _res.x || cell.y >= _res.y) { return; }

  let feed = props.x;
  let kill = props.y;
  let d_a = props.z;
  let d_b = props.w;
  let delta_time = 1.0;

  let oldA = statein[ index(cell.x, cell.y, false) ];
  let oldB = statein[ index(cell.x, cell.y, true)  ];

  let newA = oldA + (d_a * laplacian(cell.x, cell.y, false) - oldA * oldB * oldB + feed * (1 - oldA)) * delta_time;
  let newB = oldB + (d_b * laplacian(cell.x, cell.y, true) + oldA * oldB * oldB - (kill + feed) * oldB) * delta_time;

  let mouse_active = mouse.z != 0.0 && (length(vec2f(cell.xy) / res - mouse.xy) < 0.05);
  stateout[ index(cell.x, cell.y, false) ] = clamp(select(newA, 0.0, mouse_active), 0.0, 1.0);
  stateout[ index(cell.x, cell.y, true)  ] = clamp(select(newB, 1.0, mouse_active), 0.0, 1.0);
}
