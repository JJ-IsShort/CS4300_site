import { default as gulls } from "./gulls/gulls.js";
import { default as Mouse } from "./gulls/helpers/mouse.js";
import { Pane } from "https://cdn.jsdelivr.net/npm/tweakpane@4.0.5/dist/tweakpane.min.js";

const errorOverlay = document.getElementById("error-overlay");
const errorMessage = document.getElementById("error-message");

function showError(msg) {
  // I love how this error thing looks and the funny thing is that
  // ideally no one will ever see it.
  errorMessage.textContent = msg;
  errorOverlay.classList.add("visible");
}

const print = console.log;

async function initWebGPU() {
  const sg = await gulls.init(),
    size = window.innerWidth * window.innerHeight,
    state = new Float32Array(size * 2);

  const frag = await gulls.import("./frag.wgsl"),
    frag_shader = gulls.constants.vertex + frag,
    compute = await gulls.import('./compute.wgsl');

  for (let i = 0; i < size; i++) {
  //   state[i] = Math.random();
  // }
    state[i * 2 + 0] = 1.0;
    state[i * 2 + 1] = Math.random() < 0.01 ? 1.0 : 0.0;
  }

  const pane = new Pane();
  const params = { feed: 0.055, kill: 0.062, d_a: 1.0, d_b: 0.5 };
  const params_uniform = sg.uniform(Object.values(params));

  const set_param = function(id, v) {
    // let vals = [...params_uniform.value];
    // vals[id] = v;
    params_uniform.value = Object.values(params);
  }

  pane.addBinding(params, "feed", { min: 0, max: 1, label: 'feed' }).on('change', v => set_param(0, v));
  pane.addBinding(params, "kill", { min: 0, max: 1, label: 'kill' }).on('change', v => set_param(1, v));
  pane.addBinding(params, "d_a", { min: 0, max: 1, label: 'd_a' }).on('change', v => set_param(2, v));
  pane.addBinding(params, "d_b", { min: 0, max: 1, label: 'd_b' }).on('change', v => set_param(3, v));

  const statebuffer1 = sg.buffer(state);
  const statebuffer2 = sg.buffer(state);
  const res = sg.uniform([window.innerWidth, window.innerHeight]);

  Mouse.init();

  const mouse = sg.uniform(Mouse.values);

  const render_pass = await sg.render({
    shader: frag_shader,
    data: [
      res,
      sg.pingpong(statebuffer1, statebuffer2)
    ],
  });

  const compute_pass = sg.compute({
    shader: compute,
    data: [
      res,
      sg.pingpong(statebuffer1, statebuffer2),
      mouse,
      params_uniform,
    ],
    onframe() { mouse.value = Mouse.values },
    dispatchCount: [Math.round(gulls.width / 8), Math.round(gulls.height / 8), 1],
    times: 10,
  })

  sg.run(compute_pass, render_pass)
}

initWebGPU().catch((err) => {
  showError(String(err));
  console.error(err);
});
